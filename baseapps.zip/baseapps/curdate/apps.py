from django.apps import AppConfig


class CurdateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'curdate'
